Python app for AWS Lambda

Build add
poetry build